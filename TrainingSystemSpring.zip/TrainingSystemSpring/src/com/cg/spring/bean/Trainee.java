package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="trainee")
//@SequenceGenerator(name="trainee_id_sequence",sequenceName="traineeid_seq")
public class Trainee {
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="trainee_id_sequence")
	@Column(name="trainee_id")
	private int traineeId;
	@Column(name="trainee_name")
	private String traineeName;
	@Column(name="trainee_domain")
	private String traineeDomain;
	@Column(name="trainee_location")
	private String traineeLocation;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

}
