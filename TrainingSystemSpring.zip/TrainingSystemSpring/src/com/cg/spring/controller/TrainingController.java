package com.cg.spring.controller;




import java.util.List;






import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.bean.Trainee;
import com.cg.spring.service.TraineeService;





@Controller
public class TrainingController {
	@Autowired
	TraineeService service;
	
	
	@RequestMapping("/login")
	public String ValidatePage(Model model, @RequestParam("name") String uname,@RequestParam("pwd") String password)
	{
		if(uname.equals("admin") && password.equals("123"))
		{
		return "Operation";
		}
		else
			return "Error";
	}
	
	@RequestMapping("/addTrainee")
	public String AddTraineeRecord(Model model)
	{
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "AddTraineeDetails";
	}
	
	@RequestMapping("/TraineeDetails")
	public String showTraineeDetailsPage(Model model)
	{
		List<Trainee> list=service.getTraineeList();
		model.addAttribute("traineeList",list);
		
		return "TraineeInfo";
	}
	@RequestMapping("/insertTrainee")
	public String InsertTraineeRecord(Model model, @ModelAttribute("trainee") Trainee trainee)
	{
		trainee=service.addTrainee(trainee);
		System.out.println("in controller");
		model.addAttribute("trainee",trainee);
		return "Success";
		
	}
	
//	@RequestMapping("/deletePage")
//	public String deleteTraineeInfo(Model model,@RequestParam("traineeId") int traineeid)
//	{
//	Trainee	trainee=service.getTraineeDetails(traineeid);
//		model.addAttribute("trainee",trainee);
//		
//		return "DeleteOperation";
//	
//	}
//	@RequestMapping("/deletePermanent")
//	
//		public String deletePermanent(Model model,@RequestParam("traineeid") int traineeId)
//		{
//			
//			service.deleteTrainee(traineeId);
//		
//			return"Operation";
//		}
	@RequestMapping("/retrieve")
	
	public String retrieve(Model model)
	{
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return"Retrieve";
	}
	@RequestMapping("/retrieveTrainee")
	
	public String retrieveTrainee(Model model, @ModelAttribute("trainee") Trainee trainee)
	{
		trainee=service.getTraineeDetails(trainee.getTraineeId());
		model.addAttribute("trainee",trainee);
		return "Retrieve";
	}
	@RequestMapping("/Traineeupdate")
	public String updateTrainee(Model model)
	{
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return"UpdateId";
	}
	@RequestMapping("/showupdate")
	
	public String showTraineeUpdate(Model model,@ModelAttribute("trainee") Trainee trainee)
	
{
		Trainee trainee1=service.getTraineeDetails(trainee.getTraineeId());
		System.out.println(trainee.getTraineeId());
		System.out.println(trainee.getTraineeName());
		model.addAttribute("trainee",trainee1);
		 return "UpdateId";
		
	}
	@RequestMapping("/finallyupdate")
	
	public String updateTraineeRecord(Model model, @ModelAttribute("trainee") Trainee trainee)
	{
        service.updateTrainee(trainee);
	    model.addAttribute("trainee",trainee);
		model.addAttribute("updateMsg","Book updated Successfully");
		return "Success";
	}
@RequestMapping("/DeleteId")
	
	public String deleteTrainee(Model model)
	{
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "DeleteOperation";
	}
@RequestMapping("/deletePage")
public String deleteTraineeInfo(Model model,@ModelAttribute("trainee") Trainee trainee)
{
  Trainee trainee2=service.getTraineeDetails(trainee.getTraineeId());//object is needed to pass all the database value then only all values vl be printed
	model.addAttribute("trainee",trainee2);
	
	return "DeleteOperation";

}
@RequestMapping("/deletePermanent")

	public String deletePermanent(Model model,@RequestParam("traineeid") int traineeId)
	{
	
		service.deleteTrainee(traineeId);
	
	return"Operation";
	}
	}



