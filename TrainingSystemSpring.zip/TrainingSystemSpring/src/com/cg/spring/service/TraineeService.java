package com.cg.spring.service;

import java.util.List;

import com.cg.spring.bean.Trainee;

public interface TraineeService {
	public Trainee addTrainee(Trainee trainee);
	public Trainee getTraineeDetails(int bookid);
	public Trainee deleteTrainee(int traineeid);
	public List<Trainee> getTraineeList();
	public Trainee updateTrainee(Trainee trainee);
}
