package com.cg.spring.basic.bean;

public class Employee {
	
	String empName;
	Department dept;
	
	public Employee(Department d)
	{
		dept=d;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", dept=" + dept + "]";
	}
	

}
