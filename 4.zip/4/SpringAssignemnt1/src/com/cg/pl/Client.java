package com.cg.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;

class Client {
	public static void main(String[] args) {
		 ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		 Employee emp=(Employee) context.getBean("emp");
		 System.out.println("Employee Details");
		 System.out.println("Id is:"+emp.getEmpId());
		 System.out.println("Name is:"+emp.getEmpName());
		 System.out.println("Salary is:"+emp.getSalary());
		 System.out.println("BusinessUnit:"+emp.getBusinessUnit());
		 System.out.println("Age is:"+emp.getAge());
		 
	}

}
