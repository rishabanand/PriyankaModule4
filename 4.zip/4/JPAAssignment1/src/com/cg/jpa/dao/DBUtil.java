package com.cg.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {
	 static EntityManagerFactory entityfactory;
	 static EntityManager entitymanager;
	 static{
		 entityfactory=Persistence.createEntityManagerFactory("JPAAssignment1");
	 }
	 
	 public static EntityManager getEntityManager()
	 {
		 
			 entitymanager=entityfactory.createEntityManager();
			
		 
		 return entitymanager;
	 }
	 

}
