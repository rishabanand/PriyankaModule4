package com.cg.jpa.ui;

import java.util.Scanner;

import com.cg.jpa.dto.Author;
import com.cg.jpa.service.AuthorServiceImpl;
import com.cg.jpa.service.IAuthorService;

public class MyMain {
	public static void main(String[] args) {
		IAuthorService service=new AuthorServiceImpl();
		Scanner sc= new Scanner(System.in);
		Author author=new Author();
		System.out.println("1:Press 1 for add");
		System.out.println("2:Press 2 for delete");
		System.out.println("3:Press 3 for search");
		System.out.println("4:Press 4 for update");
		System.out.println("Enter your choice");
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			author.setAuthorId(1003);
			author.setFirstName("rameshkumar");
			author.setMiddleName("kumar");
			author.setLastName("sayal");
			author.setPhoneNo(9087654);
			service.addauthor(author);
			break;
			
		case 2:
			service.deleteauthor(1001);
			break;
		
		case 3:
			Author find=service.findauthor(1003);
		    System.out.println("First Name:"+find.getFirstName());
		    System.out.println("Middle Name:"+find.getMiddleName());
			System.out.println("Last Name:"+find.getLastName());
			System.out.println("Phone No:"+find.getPhoneNo());
			
			break;
		
		case 4:
           service.updateauthor(1003, "nitin", "Kumar", "seth", 9987654);
			break;
		}
	
		
		
		
	}

}