package com.cg.jpa.service;

import com.cg.jpa.dto.Author;

public interface IAuthorService {
	public int addauthor(Author author);
	public int updateauthor(int id,String fname,String mname,String lname,int phoneno);
	public int deleteauthor(int id);
	public Author findauthor(int id);
	

}
