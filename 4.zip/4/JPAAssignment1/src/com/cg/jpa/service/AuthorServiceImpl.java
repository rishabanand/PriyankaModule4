package com.cg.jpa.service;

import com.cg.jpa.dao.AuthorDaoImpl;
import com.cg.jpa.dao.IAuthorDao;
import com.cg.jpa.dto.Author;

public class AuthorServiceImpl implements IAuthorService {
	IAuthorDao dao=new AuthorDaoImpl();

	@Override
	public int addauthor(Author author) {
		return dao.addauthor(author);
		
	}

	
	@Override
	public int deleteauthor(int id) {
		
		return dao.deleteauthor(id);
	}

	@Override
	public Author findauthor(int id) {
		return dao.findauthor(id);
	}

	@Override
	public int updateauthor(int id, String fname, String mname, String lname,
			int phoneno) {
		
		return dao.updateauthor(id, fname, mname, lname, phoneno);
	}

}
