package com.cg.spring.anno.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.anno.bean.Employee;

public class client {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Employee employee=(Employee) context.getBean("emp");
		employee.setEmpid(111);
		employee.setEmpName("ashpri");
		employee.getDept().setDeptId(1211);
		employee.getDept().setDeptName("Admin");
		System.out.println(employee);
	}

}
