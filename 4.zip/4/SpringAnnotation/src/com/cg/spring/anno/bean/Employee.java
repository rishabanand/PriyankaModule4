package com.cg.spring.anno.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {
	
	
	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empid=" + empid + ", dept="
				+ dept + "]";
	}
	private String empName;
	private int empid;
	@Autowired
	private Department dept;
	
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	

}
