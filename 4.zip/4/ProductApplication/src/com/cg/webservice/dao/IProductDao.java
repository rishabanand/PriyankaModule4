package com.cg.webservice.dao;

public interface IProductDao {

}
