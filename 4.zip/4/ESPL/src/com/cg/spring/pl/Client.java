package com.cg.spring.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.spel.City;
import com.cg.spring.spel.DBConnection;

public class Client {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		City city=(City) context.getBean("city");
		System.out.println("city"+city.getName());
		System.out.println("state"+city.getState());
		System.out.println("population"+city.getPopulation());
		
	DBConnection connection= (DBConnection) context.getBean("dbconnection");
		System.out.println("username: "+connection.getUsername());
		System.out.println("password: "+connection.getPassword());
		System.out.println("url: "+connection.getUrl());
	}

}
