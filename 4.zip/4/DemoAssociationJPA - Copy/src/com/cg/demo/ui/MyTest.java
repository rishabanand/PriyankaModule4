package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demo.dto.User;
import com.cg.demo.dto.Vech;

public class MyTest {
	public static void main(String[] args) {
		
	EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("DemoAssociationJPA");
	EntityManager em=emFactory.createEntityManager();
	
	Vech ve=new Vech();
	ve.setVechId(10);
	ve.setVechName("car");
	
	Vech ve2=new Vech();
	ve2.setVechId(11);
	ve2.setVechName("jeep");
	
	User u=new User();
	u.setUserId(1);
	u.setUserName("priya");
	List<Vech> my=new ArrayList<>();
	my.add(ve);
	my.add(ve2);
	u.setV(my);
	//u.setV(ve);//Injecting vehicle into user
	
	
	em.getTransaction().begin();
	em.persist(ve);
	em.persist(ve2);
	em.persist(u);
	
    em.getTransaction().commit();
	em.close();
	emFactory.close();
	
	
	}

}
