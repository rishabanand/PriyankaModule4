package com.cg.demo1jpa.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demo1jpa.dto.Employee;

public class MyMain {
	public static void main(String[] args) {
		
		
		Employee emp=new Employee();
		emp.setEmpId(1003);
		emp.setEmpName("ashpri");
		emp.setEmpDepartment("MainFrame");
		emp.setEmpSalary(12000.24);
		
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("DemoJPA");
		EntityManager em=entityManagerFactory.createEntityManager();
		//Insert Data
//		em.getTransaction().begin();
//		em.persist(emp);
//		em.getTransaction().commit();
//		em.close();
//		entityManagerFactory.close();
		//Find
//		em.getTransaction().begin();
//	    Employee efind=em.find(Employee.class, 1002);
//		em.close();
//		System.out.println("ID IS"+efind.getEmpId());
//		System.out.println("Name IS"+efind.getEmpName());
//		System.out.println("Salary IS"+efind.getEmpSalary());
//		System.out.println("Dept IS"+efind.getEmpDepartment());
		//Remove
//		em.getTransaction().begin();
//		Employee eremove=em.find(Employee.class,1001);
//        em.remove(eremove);
//		em.getTransaction().commit();
//		em.close();
//		entityManagerFactory.close();
//		
		//Update
		em.getTransaction().begin();
		Employee eupdate=em.find(Employee.class,1002);
		eupdate.setEmpName("aman");
		eupdate.setEmpSalary(12000);
		eupdate.setEmpDepartment(".Net");
		em.merge(eupdate);
		em.getTransaction().commit();
		em.close();
		entityManagerFactory.close();
	}

}
