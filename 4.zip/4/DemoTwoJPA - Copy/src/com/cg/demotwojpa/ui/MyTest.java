package com.cg.demotwojpa.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.demotwojpa.dto.Project;
import com.cg.demotwojpa.service.IProjectService;
import com.cg.demotwojpa.service.ProjectServiceImpl;

public class MyTest {
	public static void main(String[] args) {
		IProjectService projectService=new ProjectServiceImpl();
		Project p=new Project();
		int choice;
		 Scanner sc=new Scanner(System.in);
		System.out.println("1:List,2:Add,3:Delete 4:Update 5:Search");
	    System.out.println("Enter Your Choice");
		choice=sc.nextInt();
		//Show All
		switch(choice)
		{
		case 1:
			List<Project> alldata=projectService.showAllproject();  
			   for(Project project:alldata)
			   {
				   System.out.println("ID is"+project.getProjectId());
				   System.out.println("Name is"+project.getProjectName());
				   System.out.println("Department is:"+project.getProjectDepartment());
			   }
		break;
			//add
		case 2:
			   Scanner sc1=new Scanner(System.in);
			   System.out.println("Enter Your Project Name");
			   String pname=sc1.next();
			   System.out.println("Enter Your Project Department");
			   String dname=sc1.next();
			   p.setProjectName(pname);
			   p.setProjectDepartment(dname);
			   int id=projectService.addProject(p);
			   System.out.println("Project Id is"+id);
		break;
			//delete
		case 3:
			System.out.println("Enter The Id to be Deleted");
			int rid=sc.nextInt();
			projectService.removeProject(rid);
		break;
			//update
		case 4:
		System.out.println("Enter the ID");
			id=sc.nextInt();
			System.out.println("enter the project name to be updated");
			pname=sc.next();
			System.out.println("Enter the departmnet name");
			dname=sc.next();
			Project pupdate=new Project(); 
			pupdate.setProjectId(id);
			pupdate.setProjectName(pname);
			pupdate.setProjectDepartment(dname);
		projectService.updateProject(pupdate);
		break;
			//serach
		case 5:
			System.out.println("Enter the ID");
			id=sc.nextInt();
			Project pfind=projectService.findProject(id);
			System.out.println("name is:"+pfind.getProjectName());
			System.out.println("dept is"+pfind.getProjectDepartment());
		break;
		}
		
	}
} 
		//p.setProjectId(1001);
//		p.setProjectName("BETA LEVEL");
//		p.setProjectDepartment("GE");
//		projectService.addProject(p);
//		projectService.removeProject(1001);
//	    projectService.updateProject(1001);
//	  Project pfind=projectService.findProject(1001);
//		System.out.println("ID IS"+pfind.getProjectName());
//		System.out.println("Name IS"+pfind.getProjectDepartment());
//	