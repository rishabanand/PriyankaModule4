package com.cg.demotwojpa.service;

import java.util.List;

import com.cg.demotwojpa.dao.IProjectDao;
import com.cg.demotwojpa.dao.Projectdaoimpl;
import com.cg.demotwojpa.dto.Project;

public class ProjectServiceImpl implements IProjectService {
	IProjectDao projectDao=new Projectdaoimpl();

	@Override
	public int addProject(Project proj) {
		return projectDao.addProject(proj);
		
	}

	@Override
	public void removeProject(int projId) {
		//projectDao.removeProject(projId);
		projectDao.removeProject(projId);
	}

	@Override
	public Project findProject(int projId) {
		
		return projectDao.findProject(projId);
	}

	

	@Override
	public List<Project> showAllproject() {
		return projectDao.showAllproject();
	}

	@Override
	public void updateProject(Project pro) {
		 projectDao.updateProject(pro);
		
	}

	
	

}
