package com.cg.demotwojpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ProjectUtil {

	 static EntityManagerFactory entityfactory;
	 static EntityManager entitymanager;
	 static{
		 entityfactory=Persistence.createEntityManagerFactory("DemoTwoJPA");
	 }
	 
	 public static EntityManager getEntityManager()
	 {
		 
			 entitymanager=entityfactory.createEntityManager();
			
		 
		 return entitymanager;
	 }
	 
}
