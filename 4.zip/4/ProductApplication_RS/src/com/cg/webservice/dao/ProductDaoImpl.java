package com.cg.webservice.dao;

public class ProductDaoImpl {

}
