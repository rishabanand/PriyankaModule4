package com.cg.webservice.dao;

import java.util.List;

import com.cg.webservice.bean.Product;

public interface IProductDao {
	public float getProductPrice(String productName);
	public List<Product> getProductList();
	public Product addProduct(Product product);

}
