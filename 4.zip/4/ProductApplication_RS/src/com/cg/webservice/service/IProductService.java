package com.cg.webservice.service;

public interface IProductService {

}
