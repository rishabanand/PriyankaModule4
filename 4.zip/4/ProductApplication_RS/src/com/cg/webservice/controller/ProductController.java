package com.cg.webservice.controller;
import javax.ws.rs.Path;

@Path(value="/products")
public class ProductController {

	public ProductController() {
		
	}

}
