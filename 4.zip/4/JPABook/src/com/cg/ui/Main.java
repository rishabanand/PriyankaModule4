package com.cg.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.dto.Author;
import com.cg.dto.Book;



public class Main {
	public static void main(String[] args) {
		EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("JPABook");
		EntityManager em=emFactory.createEntityManager();
		
		Book book=new Book();
		book.setIsbn(1234);
		book.setPrice(900);
		book.setTitle("love");
		
		Book book1=new Book();
		book1.setIsbn(4567);
		book1.setPrice(800);
		book1.setTitle("precious");
		
		Author author=new Author();
		author.setId(1);
		author.setName("kanik");
		
		List<Book> my=new ArrayList<>();
		my.add(book);
		my.add(book1);
		author.setBook(my);
		
		
		em.getTransaction().begin();
		em.persist(book);
		em.persist(book1);
		em.persist(author);
		em.getTransaction().commit();
		
		
		Query queryone=em.createNamedQuery("getALLData");
		List<Book> mylist=queryone.getResultList();
		for(Book books:mylist)
		   {
			   System.out.println("ISBN is"+books.getIsbn());
			   System.out.println("Price is"+books.getPrice());
			   System.out.println("tITLE is:"+books.getTitle());
		   }
		
		
		Query queryone1=em.createQuery(" FROM Book WHERE price BETWEEN 500 AND 1000");
		List<Book> list=queryone.getResultList();
		for(Book books:list)
		   {
			   System.out.println("tITLE is:"+books.getTitle());
		   }
		
	
		
		em.close();
		emFactory.close();
		
		
		Query queryone2=em.createQuery(" FROM Book WHERE price BETWEEN 500 AND 1000");
		List<Book> list1=queryone2.getResultList();
		for(Book books:list1)
		   {
			   System.out.println("tITLE is:"+books.getTitle());
		   }
		em.close();
		emFactory.close();
		
		
	}

}
