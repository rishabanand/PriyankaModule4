package com.cg.service;

import java.util.List;

import com.cg.dto.Book;

public interface IBookService {
	public List<Book> allbooks();

}
