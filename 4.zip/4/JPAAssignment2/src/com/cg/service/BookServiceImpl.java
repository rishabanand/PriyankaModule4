package com.cg.service;

import java.util.List;

import com.cg.dao.BookDaoImpl;
import com.cg.dao.IBookDao;
import com.cg.dto.Book;

public class BookServiceImpl implements IBookService{
	IBookDao dao=new BookDaoImpl();

	@Override
	public List<Book> allbooks() {
		
		return dao.allbooks();
	}

	
	

}
