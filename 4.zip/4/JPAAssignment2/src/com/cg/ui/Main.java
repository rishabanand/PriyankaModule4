package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



import com.cg.dto.Author;
import com.cg.dto.Book;
import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;

public class Main {
	public static void main(String[] args) {
		
	EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("JPAAssignment2");
	EntityManager em=emFactory.createEntityManager();
	IBookService service=new BookServiceImpl();
	Book book=new Book();
	book.setIsbn(1234);
	book.setPrice(100);
	book.setTitle("love");
	
	Book book1=new Book();
	book1.setIsbn(4567);
	book1.setPrice(200);
	book1.setTitle("pencil");
	
	Author author=new Author();
	author.setId(1);
	author.setName("kanik");
	
	List<Book> my=new ArrayList<>();
	my.add(book);
	my.add(book1);
	author.setBook(my);
	
	
	em.getTransaction().begin();
	em.persist(book);
	em.persist(book1);
	em.persist(author);
	em.getTransaction().commit();
	em.close();
	emFactory.close();
	int choice;
	
	System.out.println("1.select allbooks ");
	System.out.println("Enter Choice");
	Scanner sc=new Scanner(System.in);
	choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		List<Book> alldata=service.allbooks();
		for(Book books:alldata)
		   {
			   System.out.println("ISBN is"+books.getIsbn());
			   System.out.println("Price is"+books.getPrice());
			   System.out.println("tITLE is:"+books.getTitle());
		   }
		
		
		break;
		
		
	case 2:break;
		
	}
	

	
	
	
	
	
	}
}
