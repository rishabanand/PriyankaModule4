package com.cg.dao;

import java.util.List;

import com.cg.dto.Book;

public interface IBookDao {
	public List<Book> allbooks();

}
