package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;



import com.cg.dto.Book;

public class BookDaoImpl implements IBookDao{
	EntityManager em;

	@Override
	public List<Book> allbooks() {
		Query queryone=em.createNamedQuery("getALLData");
		//Query queryone=em.createQuery("FROM Book");
		List<Book> mylist=queryone.getResultList();
		return mylist;
		
	}

}
