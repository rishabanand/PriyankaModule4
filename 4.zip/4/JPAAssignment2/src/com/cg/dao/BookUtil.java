package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class BookUtil {
	static EntityManagerFactory entityfactory;
	 static EntityManager entitymanager;
	 static{
		 entityfactory=Persistence.createEntityManagerFactory("JPAAssignment2");
	 }
	 
	 public static EntityManager getEntityManager()
	 {
		 
			 entitymanager=entityfactory.createEntityManager();
			
		 
		 return entitymanager;
	 }
}
