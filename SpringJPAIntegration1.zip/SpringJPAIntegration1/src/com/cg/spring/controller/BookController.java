package com.cg.spring.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;
import com.cg.spring.service.BookService;

@Controller

public class BookController {
	@Autowired
	BookService service;
	
	@RequestMapping("/addBookPage")
	public String showAddBookPage(Model model)
	{
		BookDetails book=new BookDetails();
		List<Author> list=service.getAuthorList();
		model.addAttribute("authorList",list);
		model.addAttribute("book",book);
		return "AddBookDetails";
	}
	@RequestMapping("/insertBook")
	public String InsertBookRecord(Model model, @ModelAttribute("book")  BookDetails book)
	{
		book=service.addBookDetails(book);
		model.addAttribute("book",book);
		return "Success";
	}
	@RequestMapping("/getBookListPage")
	public String getBookList(Model model)
	{
		System.out.println("get");
		 List<BookDetails> list=service.getBookList();
		 model.addAttribute("bookList",list);
		// System.out.println("review"+list);
		return "BookList";
	}
	@RequestMapping("showUpdateBookPage")
	public String showUpdatePage(Model model, @RequestParam("bookid") int bookid)
	{
		BookDetails book=service.getBookDetails(bookid);
		model.addAttribute("book",book);
		return "UpdateBook";
	}
	@RequestMapping("updateBook")
	public String updateBookRecord(Model model, @ModelAttribute("book") BookDetails book)
	{
		//System.out.println("UPDATE");
	    service.updateBook(book);
	    model.addAttribute("book",book);
		model.addAttribute("updateMsg","Book updated Successfully");
		return "Success";
	}
	@RequestMapping("DeleteBookPage")
	public String removeBook(Model model,@RequestParam("bookid") int bookid)
	{
		//System.out.println("BOOK id : "+ bookid);
		service.removeBook(bookid);
		
		List<BookDetails> tlist=service.getBookList();
		model.addAttribute("bookList",tlist);
		System.out.println("After deleting"+tlist);
		return "BookList";
	
	}
	@RequestMapping("getBookYear")
	public String getBookYearWise(Model model)
	{
		return "GetBook";
	
	}
	@RequestMapping("getBookYearRange")
	public String getBookYearWiseFinal(Model model,@RequestParam("year1") int year1,@RequestParam("year2") int year2 )
	
	{
		System.out.println(year1 + " "+ year2);
		List<BookDetails> list=service.getBookYear(year1, year2);
		model.addAttribute("list",list);
		System.out.println(list);
		return "FinalGetList";
	
	}
	
	
}
