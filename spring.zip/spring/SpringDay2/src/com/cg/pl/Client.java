package com.cg.pl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.Employee;

public class Client {

	public static void main(String[] args) {
		 ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		 Employee emp=(Employee) context.getBean("emp");
		 System.out.println(emp.getName());
		 System.out.println(emp.getDoj());
	} 
}
